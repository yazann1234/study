/* =========================================================
   MyStudy — shared app logic
   Data store keys (localStorage):
   ms_theme            'light' | 'dark'
   ms_done             { "chemistry:u1:l1": true, ... }
   ms_quiz             { "chemistry:u1": true, ... }
   ms_fav              { "chemistry:u1:l1": true, ... }
   ms_notes            [ {id,text,ts}, ... ]
   ms_lastlesson       { section, unit, lesson, title }
   ms_video_pos        { "chemistry:u1:l1": seconds }
   ms_reminders        'on' | 'off'
   ========================================================= */

const ICONS = {
  home:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/></svg>`,
  book:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2Z"/><path d="M19 19H6a2 2 0 0 1 0-4h13"/></svg>`,
  cal:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>`,
  chart:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/></svg>`,
  quiz:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  note:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9Z"/><path d="M14 3v6h6"/></svg>`,
  heart:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8Z"/></svg>`,
  gear:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/></svg>`,
  moon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>`,
  sun:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>`,
  bell:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>`,
  search:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>`,
  download:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>`,
  play:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>`,
  check:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,
  arrow:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>`,
  flask:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2h6M10 2v6.5L4.5 18a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L14 8.5V2"/></svg>`,
  langs:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h9M9 3v2c0 4.5-2.5 8-6 9.5M6 9.5c1.4 2 3.5 3.3 5.8 4"/><path d="m14 21 4-9 4 9M15.5 18h5"/></svg>`,
  chat:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-8.9 8.4 9 9 0 0 1-3.8-.9L3 20l1.1-4.3A8.4 8.4 0 1 1 21 11.5Z"/></svg>`,
  pulse:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>`,
  timer:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/></svg>`,
};
function icon(name){ return ICONS[name] || ''; }

/* ---------- storage helpers ---------- */
const Store = {
  get(k, d){ try{ const v = localStorage.getItem(k); return v===null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
};

/* ---------- section registry ---------- */
const SECTIONS = {
  chemistry:     { title:'الكيمياء',        en:'Chemistry',           icon:'flask', color:'var(--chem)', page:'chemistry.html' },
  english:       { title:'الإنجليزي',       en:'English',             icon:'langs', color:'var(--eng)',  page:'english.html' },
  communication: { title:'مهارات الاتصال',  en:'Communication Skills',icon:'chat',  color:'var(--comm)', page:'communication.html' },
  medical:       { title:'المصطلحات الطبية',en:'Medical Terminology', icon:'pulse', color:'var(--med)',  page:'medical.html' },
};

/* Lightweight index of unit + lesson titles, mirrors the per-section data files.
   Used by pages (favorites/quizzes/progress) that don't load a section's full data. */
const UNIT_TITLES = {
  chemistry:     { u1:'الروابط الكيميائية', u2:'التفاعلات الكيميائية', u3:'الكيمياء العضوية', u4:'المحاليل والحسابات الكيميائية' },
  english:       { u1:'أساسيات القواعد', u2:'بناء المفردات', u3:'القراءة والكتابة', u4:'التحدث' },
  communication: { u1:'أساسيات التواصل', u2:'مهارات الاستماع', u3:'العرض والتقديم', u4:'التواصل المهني' },
  medical:       { u1:'المصطلحات الأساسية', u2:'أجهزة الجسم', u3:'الأمراض والتشخيص', u4:'الأدوية والعلاج' },
};
const LESSON_TITLES = {
  'chemistry:u1:l1':'الرابطة التساهمية','chemistry:u1:l2':'الرابطة الأيونية','chemistry:u1:l3':'الرابطة الفلزية',
  'chemistry:u2:l1':'موازنة المعادلات الكيميائية','chemistry:u2:l2':'أنواع التفاعلات الكيميائية','chemistry:u2:l3':'معدل التفاعل والعوامل المؤثرة',
  'chemistry:u3:l1':'الهيدروكربونات','chemistry:u3:l2':'المجموعات الوظيفية','chemistry:u3:l3':'البوليمرات',
  'chemistry:u4:l1':'التركيز المولاري','chemistry:u4:l2':'التخفيف وحساباته',
  'english:u1:l1':'قواعد الأزمنة في اللغة الإنجليزية','english:u1:l2':'المضارع البسيط مقابل الماضي البسيط','english:u1:l3':'أفعال الحال (Modal Verbs)',
  'english:u2:l1':'المفردات الأكاديمية الشائعة','english:u2:l2':'المرادفات والأضداد','english:u2:l3':'الكلمات المركّبة والتعابير',
  'english:u3:l1':'مهارات الفهم القرائي','english:u3:l2':'كتابة الفقرة والمقال',
  'english:u4:l1':'مخارج الحروف والنطق الصحيح','english:u4:l2':'محادثات يومية شائعة',
  'communication:u1:l1':'التواصل الفعّال','communication:u1:l2':'لغة الجسد وتأثيرها',
  'communication:u2:l1':'الاستماع الفعّال','communication:u2:l2':'إدارة النقاش وحل الخلافات',
  'communication:u3:l1':'تقديم عرض تقديمي ناجح','communication:u3:l2':'التغلب على رهبة التحدث',
  'communication:u4:l1':'كتابة البريد الإلكتروني المهني','communication:u4:l2':'مهارات المقابلة الشخصية',
  'medical:u1:l1':'البادئات واللواحق الطبية','medical:u1:l2':'الجذور الطبية الشائعة','medical:u1:l3':'مصطلحات الاتجاهات التشريحية',
  'medical:u2:l1':'الجهاز التنفسي','medical:u2:l2':'الجهاز الدوري',
  'medical:u3:l1':'مصطلحات الأمراض الشائعة','medical:u3:l2':'مصطلحات الفحوصات الطبية',
  'medical:u4:l1':'مصطلحات الأدوية','medical:u4:l2':'الإجراءات العلاجية',
};

function allLessonsFlat(){
  const out=[];
  Object.keys(window.UNITS_BY_SECTION||{}).forEach(()=>{});
  return out;
}

/* ---------- progress calculation across sections (needs UNITS data loaded per-section files: window.SECTION_DATA) ---------- */
/* Each section page defines window.SECTION_DATA = {key, units:[{id,title,lessons:[{id,title,video,summary,file}]}, quizForm}]} */
/* Home page preloads a light copy via DATA_SUMMARY below for counts + progress. */

const DATA_SUMMARY = {
  chemistry:     { units:4, lessons:11, quizzes:4 },
  english:       { units:4, lessons:10, quizzes:4 },
  communication: { units:4, lessons:8,  quizzes:4 },
  medical:       { units:4, lessons:9,  quizzes:4 },
};

function sectionProgress(key){
  const done = Store.get('ms_done', {});
  const quiz = Store.get('ms_quiz', {});
  const total = DATA_SUMMARY[key].lessons + DATA_SUMMARY[key].quizzes;
  let got = 0;
  Object.keys(done).forEach(k=>{ if(k.startsWith(key+':') && done[k]) got++; });
  Object.keys(quiz).forEach(k=>{ if(k.startsWith(key+':') && quiz[k]) got++; });
  return Math.min(100, Math.round((got/total)*100));
}
function overallProgress(){
  const keys = Object.keys(SECTIONS);
  const sum = keys.reduce((a,k)=>a+sectionProgress(k),0);
  return Math.round(sum/keys.length);
}

/* ---------- Theme ---------- */
function applyTheme(){
  const t = Store.get('ms_theme','light');
  document.documentElement.setAttribute('data-theme-root', t);
  document.body.setAttribute('data-theme', t);
}
function toggleTheme(){
  const t = Store.get('ms_theme','light') === 'light' ? 'dark' : 'light';
  Store.set('ms_theme', t);
  applyTheme();
}

/* ---------- Toast ---------- */
function toast(msg){
  let el = document.getElementById('toast');
  if(!el){ el = document.createElement('div'); el.id='toast'; document.body.appendChild(el); }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(()=>el.classList.remove('show'), 2200);
}

/* ---------- Quotes ---------- */
const QUOTES = [
  'كل صفحة تقرأها اليوم هي خطوة أقرب لحلمك غداً.',
  'النجاح مجموع مجهودات صغيرة تتكرر يوماً بعد يوم.',
  'لا تقارن يومك الأول بيوم غيرك المئة، استمر فقط.',
  'التفوق ليس صدفة .. بل عادة يومية تبنيها بنفسك.',
  'ذاكر بذكاء لا بجهد فقط، وخذ قسطاً من الراحة.',
];
function randomQuote(){ return QUOTES[Math.floor(Math.random()*QUOTES.length)]; }

/* ---------- Layout injection ---------- */
function buildSidebar(active){
  const links = [
    ['index.html','home','الرئيسية'],
    ['index.html#sections','book','المواد الدراسية'],
    ['schedule.html','cal','جدولي الدراسي'],
    ['progress.html','chart','متابعة التقدم'],
    ['quizzes.html','quiz','الكويزات'],
    ['notes.html','note','الملاحظات'],
    ['favorites.html','heart','المفضلة'],
    ['settings.html','gear','الإعدادات'],
  ];
  const navHtml = links.map(([href,ic,label])=>{
    const isActive = active===href;
    return `<a href="${href}" class="${isActive?'active':''}">${icon(ic)}<span>${label}</span></a>`;
  }).join('');

  return `
  <div class="brand">
    <div class="mark">M</div>
    <div>
      <div class="name">MyStudy</div>
      <div class="tag">خطوتك نحو مستقبل أفضل</div>
    </div>
  </div>
  <div class="who">
    <div class="avatar">ي</div>
    <div>
      <div class="hi">مرحباً بك</div>
      <div class="uname">طالب/ة مجتهد/ة 🌱</div>
    </div>
  </div>
  <nav class="mainnav">${navHtml}</nav>
  <div class="nav-sep"></div>
  <div class="grow-card">
    <div class="leaf">🌿</div>
    كن أفضل من نفسك أمس<br>كل يوم خطوة للأمام تصنع فرقاً كبيراً 💜
  </div>`;
}

function buildTopbar(){
  const t = Store.get('ms_theme','light');
  return `
  <button class="icon-btn menu-toggle" id="menuToggle" aria-label="القائمة">${icon('arrow')}</button>
  <div class="search">
    ${icon('search')}
    <input id="globalSearch" type="text" placeholder="ابحث عن أي درس أو موضوع...">
  </div>
  <button class="icon-btn" id="themeBtn" aria-label="تبديل الوضع">${icon(t==='dark'?'sun':'moon')}</button>
  <button class="icon-btn" id="bellBtn" aria-label="الإشعارات">${icon('bell')}<span class="dot"></span></button>`;
}

const SEARCH_INDEX = [
  {t:'الرابطة التساهمية', s:'chemistry', href:'chemistry.html'},
  {t:'قواعد الأزمنة في اللغة الإنجليزية', s:'english', href:'english.html'},
  {t:'التواصل الفعّال', s:'communication', href:'communication.html'},
  {t:'الجهاز التنفسي - المصطلحات', s:'medical', href:'medical.html'},
];

function initSearch(){
  const input = document.getElementById('globalSearch');
  if(!input) return;
  let box;
  input.addEventListener('input', ()=>{
    const q = input.value.trim();
    if(box) box.remove();
    if(!q) return;
    const results = SEARCH_INDEX.filter(r=>r.t.includes(q) || SECTIONS[r.s].title.includes(q));
    box = document.createElement('div');
    box.style.cssText = 'position:absolute;margin-top:52px;background:var(--card);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);width:min(420px,90vw);z-index:40;overflow:hidden;';
    box.innerHTML = results.length ? results.map(r=>`<a href="${r.href}" style="display:block;padding:12px 16px;font-size:13.5px;border-bottom:1px solid var(--line);color:var(--ink)">${r.t} <span style="color:var(--ink-dim);font-size:11px">— ${SECTIONS[r.s].title}</span></a>`).join('') : `<div style="padding:14px 16px;font-size:13px;color:var(--ink-dim)">لا توجد نتائج مطابقة</div>`;
    input.closest('.search').appendChild(box);
  });
  document.addEventListener('click', (e)=>{ if(box && !e.target.closest('.search')) { box.remove(); box=null; } });
}

function injectLayout(activeHref){
  const app = document.createElement('div');
  app.className = 'app';
  const main = document.getElementById('page-content');
  const mainHTML = main ? main.innerHTML : '';
  app.innerHTML = `
    <aside class="sidebar" id="sidebar">${buildSidebar(activeHref)}</aside>
    <div class="main">
      <div class="topbar">${buildTopbar()}</div>
      <div id="page-content">${mainHTML}</div>
    </div>`;
  document.body.innerHTML = '';
  document.body.appendChild(app);

  document.getElementById('themeBtn').addEventListener('click', ()=>{ toggleTheme(); document.getElementById('themeBtn').innerHTML = icon(Store.get('ms_theme','light')==='dark'?'sun':'moon'); });
  document.getElementById('bellBtn').addEventListener('click', ()=>{ window.location.href='schedule.html'; });
  const menuToggle = document.getElementById('menuToggle');
  if(menuToggle){ menuToggle.addEventListener('click', ()=> document.getElementById('sidebar').classList.toggle('show')); }
  initSearch();
}

document.addEventListener('DOMContentLoaded', ()=>{
  applyTheme();
});
