document.addEventListener('DOMContentLoaded', ()=>{
  const D = window.SECTION_DATA;
  document.body.setAttribute('data-section', D.key);
  injectLayout('index.html#sections');
  renderSectionHero(D);
  renderUnits(D);
});

function lessonCount(D){ return D.units.reduce((a,u)=>a+u.lessons.length,0); }

function renderSectionHero(D){
  const done = Store.get('ms_done', {});
  const quiz = Store.get('ms_quiz', {});
  const totalLessons = lessonCount(D);
  const totalQuiz = D.units.length;
  let gotL=0, gotQ=0;
  D.units.forEach(u=>{
    u.lessons.forEach(l=>{ if(done[D.key+':'+u.id+':'+l.id]) gotL++; });
    if(quiz[D.key+':'+u.id]) gotQ++;
  });
  const pct = Math.round(((gotL+gotQ)/(totalLessons+totalQuiz))*100) || 0;

  document.getElementById('page-content').insertAdjacentHTML('afterbegin', `
  <div class="section-hero">
    <div class="emoji">${icon(D.icon)}</div>
    <div>
      <div class="en">${D.en}</div>
      <h1>${D.title}</h1>
      <p style="opacity:.9;font-size:13px;margin-top:4px">${D.tagline}</p>
      <div class="stats">
        <div><b>${D.units.length}</b><span>وحدات</span></div>
        <div><b>${totalLessons}</b><span>دروس</span></div>
        <div><b>${totalQuiz}</b><span>كويزات</span></div>
      </div>
    </div>
    <div class="overall">
      <div class="ring" style="--p:${pct}%"><div class="in">${pct}%</div></div>
      <div style="font-size:11px;margin-top:6px;opacity:.9">تقدمك بالقسم</div>
    </div>
  </div>`);
}

function renderUnits(D){
  const wrap = document.createElement('div');
  wrap.id = 'unitsWrap';
  D.units.forEach((u,idx)=>{
    wrap.insertAdjacentHTML('beforeend', unitTemplate(D, u, idx));
  });
  document.getElementById('page-content').appendChild(wrap);

  // wire interactions
  document.querySelectorAll('.unit-head').forEach(h=>{
    h.addEventListener('click', ()=> h.closest('.unit').classList.toggle('open'));
  });
  document.querySelectorAll('.fav-btn').forEach(b=>{
    const key = b.dataset.key;
    const fav = Store.get('ms_fav', {});
    if(fav[key]) b.classList.add('active');
    b.addEventListener('click', (e)=>{ e.stopPropagation(); toggleFav(key, b); });
  });
  document.querySelectorAll('.done-btn').forEach(b=>{
    const key = b.dataset.key;
    const done = Store.get('ms_done', {});
    if(done[key]){ b.classList.add('active'); b.textContent=''; b.innerHTML = icon('check')+' مكتمل'; }
    b.addEventListener('click', (e)=>{ e.stopPropagation(); toggleDone(key, b); });
  });
  document.querySelectorAll('.quiz-toggle').forEach(b=>{
    b.addEventListener('click', ()=>{
      const frame = document.getElementById('frame-'+b.dataset.unit);
      frame.classList.toggle('show');
      if(frame.classList.contains('show') && !frame.dataset.loaded){
        frame.querySelector('iframe').src = b.dataset.form;
        frame.dataset.loaded = '1';
      }
    });
  });
  document.querySelectorAll('.quiz-done').forEach(b=>{
    const key = b.dataset.key;
    const quiz = Store.get('ms_quiz', {});
    if(quiz[key]){ b.classList.add('active'); b.innerHTML = icon('check')+' تم إنجاز الكويز'; }
    b.addEventListener('click', ()=>{
      const q = Store.get('ms_quiz', {});
      q[key] = !q[key];
      Store.set('ms_quiz', q);
      b.classList.toggle('active');
      b.innerHTML = q[key] ? icon('check')+' تم إنجاز الكويز' : 'وضع علامة: تم إنجاز الكويز';
      toast(q[key] ? 'أحسنت! تم تسجيل إنجاز الكويز 🎉' : 'تم إلغاء علامة الإنجاز');
      refreshRing();
    });
  });
  document.querySelectorAll('video[data-key]').forEach(v=>{
    const key = v.dataset.key;
    const pos = Store.get('ms_video_pos', {});
    if(pos[key]) v.currentTime = pos[key];
    v.addEventListener('timeupdate', ()=>{
      const p = Store.get('ms_video_pos', {});
      p[key] = v.currentTime;
      Store.set('ms_video_pos', p);
    });
    v.addEventListener('play', ()=>{
      Store.set('ms_lastlesson', { section: v.dataset.section, title: v.dataset.title });
    });
  });

  // open unit from URL hash (e.g. #unit-u2) if present, else open first unit
  const target = location.hash && document.getElementById(location.hash.slice(1));
  if(target && target.classList.contains('unit')){
    target.classList.add('open');
    setTimeout(()=> target.scrollIntoView({behavior:'smooth', block:'start'}), 150);
  } else {
    const first = document.querySelector('.unit');
    if(first) first.classList.add('open');
  }
}

function unitTemplate(D, u, idx){
  const done = Store.get('ms_done', {});
  const quizDone = Store.get('ms_quiz', {})[D.key+':'+u.id];
  const doneCount = u.lessons.filter(l=>done[D.key+':'+u.id+':'+l.id]).length;
  const unitPct = Math.round((doneCount / (u.lessons.length + 1)) * 100) + (quizDone ? Math.round(100/(u.lessons.length+1)) : 0);

  const lessonsHtml = u.lessons.map(l=>{
    const key = `${D.key}:${u.id}:${l.id}`;
    const isFav = Store.get('ms_fav', {})[key];
    const isDone = done[key];
    return `
    <div class="lesson">
      <div class="vbox">
        ${l.video
          ? `<video controls data-key="${key}" data-section="${D.key}" data-title="${l.title}" src="${l.video}" poster="${l.poster||''}"></video>`
          : `<div class="novideo">${icon('play')}<span>ضع رابط الفيديو من جهازك هنا<br>(${l.videoHint||'videos/...'})</span></div>`}
      </div>
      <div class="info">
        <h4>${l.title}</h4>
        <div class="summary">${l.summary}</div>
        <div class="actions">
          <a class="btn-outline" href="${l.file}" download>${icon('download')} تحميل ملف الشرح</a>
          <button class="fav-btn" data-key="${key}">${icon('heart')} ${isFav?'في المفضلة':'أضف للمفضلة'}</button>
          <button class="done-btn" data-key="${key}">${isDone? icon('check')+' مكتمل' : 'وضع علامة: مكتمل'}</button>
        </div>
      </div>
    </div>`;
  }).join('');

  return `
  <div class="unit" id="unit-${u.id}">
    <div class="unit-head">
      <div class="num">${idx+1}</div>
      <div>
        <h3>${u.title}</h3>
        <div class="meta">${u.lessons.length} دروس + كويز الوحدة</div>
      </div>
      <div class="chev">${icon('arrow')}</div>
    </div>
    <div class="unit-progress">
      <span>${Math.min(100,unitPct)}%</span>
      <div class="pbar"><span style="width:${Math.min(100,unitPct)}%"></span></div>
    </div>
    <div class="unit-body">
      ${lessonsHtml}
      <div class="quiz-box">
        <div class="qi">${icon('quiz')}</div>
        <div class="qt">
          <h4>كويز: ${u.title}</h4>
          <p>اختبر فهمك للوحدة عبر النموذج التفاعلي بدون مغادرة الموقع</p>
        </div>
        <button class="quiz-toggle" data-unit="${u.id}" data-form="${u.quizForm}" style="background:var(--accent);color:#fff;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:700;">فتح الكويز</button>
      </div>
      <div class="quiz-frame-wrap" id="frame-${u.id}">
        <iframe loading="lazy" title="كويز ${u.title}"></iframe>
      </div>
      <div style="margin-top:10px;text-align:left">
        <button class="quiz-done done-btn" data-key="${D.key}:${u.id}" style="display:inline-block">وضع علامة: تم إنجاز الكويز</button>
      </div>
    </div>
  </div>`;
}

function toggleFav(key, btn){
  const fav = Store.get('ms_fav', {});
  fav[key] = !fav[key];
  Store.set('ms_fav', fav);
  btn.classList.toggle('active');
  btn.innerHTML = icon('heart') + ' ' + (fav[key] ? 'في المفضلة' : 'أضف للمفضلة');
  toast(fav[key] ? 'أُضيف إلى المفضلة ❤️' : 'أُزيل من المفضلة');
}
function toggleDone(key, btn){
  const done = Store.get('ms_done', {});
  done[key] = !done[key];
  Store.set('ms_done', done);
  btn.classList.toggle('active');
  btn.innerHTML = done[key] ? icon('check')+' مكتمل' : 'وضع علامة: مكتمل';
  toast(done[key] ? 'أحسنت! تم إنجاز الدرس 🎉' : 'تم إلغاء علامة الإنجاز');
  refreshRing();
}
function refreshRing(){
  const D = window.SECTION_DATA;
  document.querySelector('.section-hero')?.remove();
  renderSectionHero(D);
}
