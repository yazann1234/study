document.addEventListener('DOMContentLoaded', ()=>{
  injectLayout('quizzes.html');
  const quizDone = Store.get('ms_quiz', {});
  const wrap = document.getElementById('quizList');
  let html = '';
  Object.entries(SECTIONS).forEach(([key,s])=>{
    html += `<h3 style="margin:18px 0 10px;color:${s.color}">${s.title}</h3>`;
    Object.entries(UNIT_TITLES[key]).forEach(([uid,utitle])=>{
      const done = quizDone[key+':'+uid];
      html += `
      <div class="quiz-box" style="background:var(--bg);margin-bottom:10px">
        <div class="qi" style="background:${s.color}">${icon('quiz')}</div>
        <div class="qt"><h4>${utitle}</h4><p>${done ? 'تم إنجاز هذا الكويز ✅' : 'لم يُنجز بعد'}</p></div>
        <a class="go" href="${s.page}#unit-${uid}" style="background:${s.color}">فتح الكويز</a>
      </div>`;
    });
  });
  wrap.innerHTML = html;
});
