document.addEventListener('DOMContentLoaded', ()=>{
  injectLayout('schedule.html');
  renderTimetable();
  initPomodoro();
  if(location.hash === '#pomodoro'){
    setTimeout(()=> document.getElementById('pomodoro').scrollIntoView({behavior:'smooth'}), 150);
  }
});

const DAYS = ['السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'];
const TIMES = ['9ص','12ظ','3م','6م'];
/* plan[timeIndex][dayIndex] = {sec, label} | null — edit freely to match your own week */
const PLAN = [
  [ {sec:'chemistry',l:'كيمياء'}, null, {sec:'english',l:'إنجليزي'}, null, {sec:'chemistry',l:'كيمياء'}, null, null ],
  [ null, {sec:'communication',l:'اتصال'}, null, {sec:'medical',l:'طبية'}, null, {sec:'communication',l:'اتصال'}, null ],
  [ {sec:'english',l:'إنجليزي'}, null, {sec:'chemistry',l:'كيمياء'}, null, {sec:'english',l:'إنجليزي'}, null, null ],
  [ null, {sec:'medical',l:'طبية'}, null, {sec:'communication',l:'اتصال'}, null, {sec:'medical',l:'طبية'}, null ],
];

function renderTimetable(){
  const el = document.getElementById('timetable');
  let html = `<div class="cell head"></div>` + DAYS.map(d=>`<div class="cell head">${d}</div>`).join('');
  TIMES.forEach((t, ti)=>{
    html += `<div class="cell time">${t}</div>`;
    DAYS.forEach((d, di)=>{
      const item = PLAN[ti][di];
      if(item){
        const color = getComputedStyle(document.body).getPropertyValue('--'+({chemistry:'chem',english:'eng',communication:'comm',medical:'med'}[item.sec]));
        html += `<div class="cell" style="padding:4px"><div class="slot" style="background:${color || 'var(--accent)'}">${item.l}</div></div>`;
      } else {
        html += `<div class="cell"></div>`;
      }
    });
  });
  el.innerHTML = html;
}

/* ---------- Pomodoro ---------- */
let pomoSeconds = 25*60, pomoRunning = false, pomoInterval = null, pomoFocus = true;
function pomoRender(){
  const m = String(Math.floor(pomoSeconds/60)).padStart(2,'0');
  const s = String(pomoSeconds%60).padStart(2,'0');
  document.getElementById('pomoTime').textContent = `${m}:${s}`;
  document.getElementById('pomoLabel').textContent = pomoFocus ? 'وقت التركيز' : 'وقت الراحة';
}
function initPomodoro(){
  pomoRender();
  document.getElementById('pomoStart').addEventListener('click', (e)=>{
    pomoRunning = !pomoRunning;
    e.target.textContent = pomoRunning ? 'إيقاف مؤقت' : 'ابدأ';
    if(pomoRunning){
      pomoInterval = setInterval(()=>{
        pomoSeconds--;
        if(pomoSeconds<0){
          pomoFocus = !pomoFocus;
          pomoSeconds = pomoFocus ? 25*60 : 5*60;
          toast(pomoFocus ? 'انتهت الراحة! ارجع للتركيز 💪' : 'وقت راحة قصيرة ☕');
        }
        pomoRender();
      }, 1000);
    } else {
      clearInterval(pomoInterval);
    }
  });
  document.getElementById('pomoReset').addEventListener('click', ()=>{
    clearInterval(pomoInterval);
    pomoRunning = false; pomoFocus = true; pomoSeconds = 25*60;
    document.getElementById('pomoStart').textContent = 'ابدأ';
    pomoRender();
  });
}
