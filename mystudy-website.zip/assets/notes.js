document.addEventListener('DOMContentLoaded', ()=>{
  injectLayout('notes.html');
  renderNotes();
});

function renderNotes(){
  const notes = Store.get('ms_notes', []);
  const grid = document.getElementById('notesGrid');
  grid.innerHTML = notes.map(n=>`
    <div class="note" data-id="${n.id}">
      <textarea placeholder="اكتب ملاحظتك هنا...">${n.text}</textarea>
      <button class="del" aria-label="حذف">✕</button>
    </div>
  `).join('') + `<button class="add-note" id="addNote">+ ملاحظة جديدة</button>`;

  grid.querySelectorAll('.note textarea').forEach(ta=>{
    ta.addEventListener('input', ()=>{
      const id = ta.closest('.note').dataset.id;
      const list = Store.get('ms_notes', []);
      const n = list.find(x=>String(x.id)===id);
      if(n){ n.text = ta.value; Store.set('ms_notes', list); }
    });
  });
  grid.querySelectorAll('.note .del').forEach(b=>{
    b.addEventListener('click', ()=>{
      const id = b.closest('.note').dataset.id;
      let list = Store.get('ms_notes', []);
      list = list.filter(x=>String(x.id)!==id);
      Store.set('ms_notes', list);
      renderNotes();
      toast('تم حذف الملاحظة');
    });
  });
  document.getElementById('addNote').addEventListener('click', ()=>{
    const list = Store.get('ms_notes', []);
    list.push({ id: Date.now(), text:'', ts: Date.now() });
    Store.set('ms_notes', list);
    renderNotes();
    const areas = grid.querySelectorAll('textarea');
    if(areas.length) areas[areas.length-1].focus();
  });
}
