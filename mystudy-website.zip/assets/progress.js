document.addEventListener('DOMContentLoaded', ()=>{
  injectLayout('progress.html');
  const overall = overallProgress();
  document.getElementById('overallRing').style.setProperty('--p', overall+'%');
  document.getElementById('overallPct').textContent = overall+'%';

  const wrap = document.getElementById('perSection');
  wrap.innerHTML = '<h3 style="margin-bottom:6px">التقدم حسب المادة</h3>' +
    Object.entries(SECTIONS).map(([key,s])=>{
      const p = sectionProgress(key);
      return `
      <div class="prog-row">
        <div class="ic" style="background:${s.color}">${icon(s.icon)}</div>
        <div class="name">${s.title}</div>
        <div class="pbar" style="flex:1"><span style="width:${p}%;background:${s.color}"></span></div>
        <div class="pct">${p}%</div>
      </div>`;
    }).join('');
});
