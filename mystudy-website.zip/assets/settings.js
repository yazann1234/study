document.addEventListener('DOMContentLoaded', ()=>{
  injectLayout('settings.html');

  const darkSwitch = document.getElementById('darkSwitch');
  if(Store.get('ms_theme','light')==='dark') darkSwitch.classList.add('on');
  darkSwitch.addEventListener('click', ()=>{ toggleTheme(); darkSwitch.classList.toggle('on'); });

  const remindSwitch = document.getElementById('remindSwitch');
  if(Store.get('ms_reminders','off')==='on') remindSwitch.classList.add('on');
  remindSwitch.addEventListener('click', ()=>{
    const now = Store.get('ms_reminders','off')==='on' ? 'off' : 'on';
    Store.set('ms_reminders', now);
    remindSwitch.classList.toggle('on');
    toast(now==='on' ? 'تم تفعيل التذكيرات' : 'تم إيقاف التذكيرات');
  });

  document.getElementById('resetBtn').addEventListener('click', ()=>{
    if(confirm('هل أنت متأكد من إعادة ضبط كل تقدمك؟ لا يمكن التراجع عن هذا الإجراء.')){
      ['ms_done','ms_quiz','ms_fav','ms_notes','ms_lastlesson','ms_video_pos'].forEach(k=>localStorage.removeItem(k));
      toast('تم إعادة ضبط التقدم بنجاح');
      setTimeout(()=> location.href='index.html', 900);
    }
  });
});
