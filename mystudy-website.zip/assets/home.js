document.addEventListener('DOMContentLoaded', ()=>{
  injectLayout('index.html');
  renderSectionCards();
  renderLatest();
  renderFeatures();
  renderContinue();
  renderTodayPlan();
  renderQuote();

  document.getElementById('newQuoteBtn').addEventListener('click', renderQuote);
  document.getElementById('pomoOpen').addEventListener('click', ()=> window.location.href='schedule.html#pomodoro');
});

function renderSectionCards(){
  const wrap = document.getElementById('sections');
  wrap.innerHTML = Object.entries(SECTIONS).map(([key,s])=>{
    const d = DATA_SUMMARY[key];
    const p = sectionProgress(key);
    return `
    <div class="scard" style="--c:${s.color}">
      <div class="icon">${icon(s.icon)}</div>
      <h3>${s.title}</h3>
      <div class="en">${s.en}</div>
      <div class="stats">
        <div><b>${d.quizzes}</b>كويزات</div>
        <div><b>${d.lessons}</b>درس</div>
        <div><b>${d.units}</b>وحدات</div>
      </div>
      <div class="progress-row">
        <span>${p}%</span>
        <div class="pbar"><span style="width:${p}%"></span></div>
      </div>
      <a class="enter" href="${s.page}">دخول القسم ${icon('arrow')}</a>
    </div>`;
  }).join('');
}

const LATEST = [
  {sec:'chemistry', title:'الرابطة التساهمية', sub:'شرح شامل مع أمثلة', href:'chemistry.html'},
  {sec:'english', title:'قواعد الأزمنة في اللغة الإنجليزية', sub:'شرح مبسّط مع تدريبات', href:'english.html'},
  {sec:'communication', title:'التواصل الفعّال', sub:'كيف تتحدث بثقة؟', href:'communication.html'},
  {sec:'medical', title:'الجهاز التنفسي', sub:'المصطلحات الأساسية', href:'medical.html'},
];
function renderLatest(){
  const wrap = document.getElementById('latestGrid');
  wrap.innerHTML = LATEST.map(v=>{
    const s = SECTIONS[v.sec];
    return `
    <div class="vcard">
      <div class="thumb" style="background:linear-gradient(160deg, ${s.color}, transparent 120%), ${s.color}22">
        <span class="badge">${s.title}</span>
        <div class="play">${icon('play')}</div>
      </div>
      <div class="body">
        <h4>${v.title}</h4>
        <div class="sub">${v.sub}</div>
        <div class="row">
          <a class="btn-solid" href="${v.href}">${icon('download')} ملخص الملف</a>
        </div>
        <div class="row" style="margin-top:8px">
          <a class="btn-outline" href="${v.href}">${icon('quiz')} فتح الكويز</a>
        </div>
      </div>
    </div>`;
  }).join('');
}

const FEATURES = [
  ['moon','وضع مظلم لراحة العين'],
  ['chart','إحصائيات تقدم تفصيلية'],
  ['home','واجهة سهلة وسلسة'],
  ['download','تحميل سريع لكل الملفات'],
  ['bell','تذكير بمواعيد المذاكرة'],
  ['cal','خطة دراسية منظمة'],
  ['quiz','فيديو + ملخص + كويز لكل درس'],
  ['check','حفظ تقدمك تلقائياً في متصفحك'],
  ['heart','مفضلة لحفظ أهم الدروس'],
  ['note','ملاحظات سريعة لكل درس'],
  ['timer','مؤقت بومودورو للتركيز'],
  ['play','أكمل آخر فيديو شاهدته تلقائياً'],
  ['search','بحث فوري في كل المحتوى'],
  ['book','محتوى متكامل بأربع مواد'],
];
function renderFeatures(){
  document.getElementById('featuresGrid').innerHTML = FEATURES.map(([ic,label])=>`
    <div class="fitem"><div class="fi">${icon(ic)}</div><span>${label}</span></div>
  `).join('');
}

function renderContinue(){
  const last = Store.get('ms_lastlesson', null);
  if(!last) return;
  const w = document.getElementById('continueWidget');
  w.style.display = 'block';
  document.getElementById('contSection').textContent = SECTIONS[last.section].title;
  document.getElementById('contTitle').textContent = last.title;
  document.getElementById('contGo').href = SECTIONS[last.section].page;
}

const TODAY = [
  {c:'var(--chem)', t:'كيمياء', time:'12:00 - 10:00 ص'},
  {c:'var(--eng)', t:'إنجليزي', time:'2:30 - 1:00 م'},
  {c:'var(--comm)', t:'مهارات الاتصال', time:'5:30 - 4:00 م'},
  {c:'var(--med)', t:'مصطلحات طبية', time:'8:30 - 7:00 م'},
];
function renderTodayPlan(){
  document.getElementById('todayPlan').innerHTML = TODAY.map(x=>`
    <div class="plan-item"><span class="plan-dot" style="background:${x.c}"></span><span class="t">${x.t}</span><span class="time">${x.time}</span></div>
  `).join('');
}

function renderQuote(){ document.getElementById('quoteText').textContent = randomQuote(); }
