document.addEventListener('DOMContentLoaded', ()=>{
  injectLayout('favorites.html');
  const fav = Store.get('ms_fav', {});
  const keys = Object.keys(fav).filter(k=>fav[k]);
  const wrap = document.getElementById('favWrap');
  if(!keys.length){
    wrap.innerHTML = `<div class="simple-card" style="text-align:center;color:var(--ink-dim)">
      ${icon('heart')}
      <p style="margin-top:10px">لا توجد دروس في المفضلة بعد — اضغط "أضف للمفضلة" داخل أي درس.</p>
    </div>`;
    return;
  }
  wrap.innerHTML = `<div class="fav-grid">` + keys.map(k=>{
    const [sec, uid] = k.split(':');
    const s = SECTIONS[sec];
    const title = LESSON_TITLES[k] || k;
    return `
    <a class="fav-item" href="${s.page}#unit-${uid}">
      <div class="ic" style="background:${s.color}">${icon(s.icon)}</div>
      <div class="t"><div class="s">${s.title}</div><div class="n">${title}</div></div>
      ${icon('arrow')}
    </a>`;
  }).join('') + `</div>`;
});
